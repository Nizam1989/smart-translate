import { Anthropic } from "@anthropic-ai/sdk";

export async function POST(req: Request) {
  const { prompt } = await req.json();

  const anthropic = new Anthropic({
    apiKey: process.env.ANTHROPIC_API_KEY,
  });

  const msg = await anthropic.messages.create({
    model: "claude-3-haiku-20240307",
    max_tokens: 1000,
    messages: [
      {
        role: "user",
        content: prompt,
      },
    ],
  });

  return Response.json({ result: msg.content });
}
